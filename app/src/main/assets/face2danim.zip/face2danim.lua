local Config = require("config")
local FaceLandmark = require("FaceLandmark")

TAG = "OF-Face2dAnim"

local vs = [[
    attribute vec2 aPosition;
    attribute vec2 aTextureCoord;
    varying vec2 vTexCoord;
    void main() 
    {
	    gl_Position = vec4(aPosition, 0.0, 1.0);
		vTexCoord = aTextureCoord;
    }
]]

local fs = [[
    precision highp float;
    uniform sampler2D uTexture;
    varying vec2 vTexCoord;
    void main()
    {
        gl_FragColor = texture2D(uTexture, vTexCoord);
        //gl_FragColor = vec4(1, 1, 1, 1);
    }
]]

local FloatPerVertex = 4
local FacePointCount = #Config.FaceLandmark / 2
local ExtPointCount = #Config.FaceExtPoint / 2

local _renderPass = nil
local _faceVbo = nil
local _faceIbo = nil
local _faceVertexBuffer = nil
local _faceTexture = nil

function table_contain(t, value)
    for k, v in ipairs(t) do
        if v == value then
            return true
        end
    end
    return false
end

function table_copy(t)
    local newTable = {}
    for k, v in pairs(t) do
        newTable[k] = v
    end 
    return newTable
end

function calcBoundingBox(ignoreIndices)
    local minx, maxx = 1.0, 0.0
    local miny, maxy = 1.0, 0.0
    local shapeList = { Config.BaseShape }
    for i = 1, #Config.ExperShapes do
         table.insert(shapeList, Config.ExperShapes[i].shape)
    end
    print("calcBoundingBox " .. tostring(#shapeList))

    for i = 1, #shapeList do
        local shape = shapeList[i]
        for j = 1, #shape / 2 do
            if not table_contain(ignoreIndices, j-1) then
                local x = shape[2 * (j - 1) + 1]
                local y = shape[2 * (j - 1) + 2]
                if minx > x then minx = x end
                if maxx < x then maxx = x end
                if miny > y then miny = y end
                if maxy < y then maxy = y end
            end
        end
    end
    return minx, maxx, miny, maxy
end

function calcShapeBoundingBox(ignoreIndices, shape)
    local minx, maxx = 1.0, 0.0
    local miny, maxy = 1.0, 0.0
    for j = 1, #shape / 2 do
        if not table_contain(ignoreIndices, j - 1) then
            local x = shape[2 * (j - 1) + 1]
            local y = shape[2 * (j - 1) + 2]
            if x > 0.0 and y > 0.0 then
                if minx > x then minx = x end
                if maxx < x then maxx = x end
                if miny > y then miny = y end
                if maxy < y then maxy = y end
            end
        end
    end
    return minx, maxx, miny, maxy
end

function getBlendshape(baseShape, expr, minx, maxx, miny, maxy)
    local bs = {}
    local shape = expr.shape
    for i = 1, #baseShape / 2 do
        if table_contain(expr.indices, i - 1) then
            local x_base = (baseShape[2 * (i - 1) + 1] - minx) / (maxx - minx)
            local y_base = (baseShape[2 * (i - 1) + 2] - miny) / (maxy - miny)
            local x = (shape[2 * (i - 1) + 1] - minx) / (maxx - minx)
            local y = (shape[2 * (i - 1) + 2] - miny) / (maxy - miny)
            table.insert(bs, x - x_base)
            table.insert(bs, y - y_base)
        else
            table.insert(bs, 0)
            table.insert(bs, 0)
        end
    end
    return bs
end

function generateNewShape(baseShape, weights)
    --local minx, maxx, miny, maxy = calcBoundingBox(Config.IgnoeIdices)
    --print(minx, maxx, miny, maxy)
    --local bs = getBlendshape(Config.BaseShape, Config.MouthOpenShape, minx, maxx, miny, maxy)
    --print(bs[93 * 2 + 1], bs[93 * 2 + 2])

    local minx, maxx, miny, maxy = calcShapeBoundingBox(Config.IgnoeIdices, baseShape)

    local bs = Config.ExperShapes[1].delta
    print(bs[93 * 2 + 1], bs[93 * 2 + 2])

    local newShape = {}
    for i = 1, #baseShape / 2 do
        local x = (baseShape[2 * (i - 1) + 1] - minx) / (maxx - minx)
        local y = (baseShape[2 * (i - 1) + 2] - miny) / (maxy - miny)
        for j = 1, #Config.ExperShapes do
            local bs = Config.ExperShapes[j].delta
            x = x + weights[j] * bs[2 * (i - 1) + 1]
            y = y + weights[j] * bs[2 * (i - 1) + 2]
        end
        --x = x + weights[1] * bs[2 * (i - 1) + 1]
        --y = y + weights[1] * bs[2 * (i - 1) + 2]
        x = x * (maxx - minx) + minx
        y = y * (maxy - miny) + miny
        table.insert(newShape, x)
        table.insert(newShape, y)
    end
    return newShape
end

function fillVertexBuffer(vertexBuffer, vertices, uvs, extPnts, extPntUvs)
    for i = 1, FacePointCount do
    	if vertices then
        	vertexBuffer:set((i - 1) * FloatPerVertex + 0, 2 * vertices[i*2-1] - 1)
        	vertexBuffer:set((i - 1) * FloatPerVertex + 1, 2 * vertices[i*2] - 1)
        end

        if uvs and uvs[i*2] then
            vertexBuffer:set((i - 1) * FloatPerVertex + 2, uvs[i*2-1])
            vertexBuffer:set((i - 1) * FloatPerVertex + 3, uvs[i*2])
        end
    end

    for i = 1, ExtPointCount do
        if extPnts then
            vertexBuffer:set(FacePointCount * FloatPerVertex + (i - 1) * FloatPerVertex + 0, 2 * extPnts[2 * (i - 1 ) + 1] - 1)
            vertexBuffer:set(FacePointCount * FloatPerVertex + (i - 1) * FloatPerVertex + 1, 2 * extPnts[2 * (i - 1 ) + 2] - 1)
        end

        if extPntUvs then
            vertexBuffer:set(FacePointCount * FloatPerVertex + (i - 1) * FloatPerVertex + 2, extPntUvs[2 * (i - 1 ) + 1])
            vertexBuffer:set(FacePointCount * FloatPerVertex + (i - 1) * FloatPerVertex + 3, extPntUvs[2 * (i - 1 ) + 2])
        end
    end
end

function midPoint(landmarks, id1, id2)
    local x = (landmarks[id1 * 2 + 1] + landmarks[id2 * 2 + 1]) / 2.0
    local y = (landmarks[id1 * 2 + 2] + landmarks[id2 * 2 + 2]) / 2.0
    return x, y
end

function segmentPoint(landmarks, id1, id2, num, i)
    local x1, y1 = landmarks[id1 * 2 + 1], landmarks[id1 * 2 + 2]
    local x2, y2 = landmarks[id2 * 2 + 1], landmarks[id2 * 2 + 2]
    local len = math.sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2))
    local x = x1 + ((x2 - x1) / len) * (len / num * i)
    local y = y1 + ((y2 - y1) / len) * (len / num * i)
    return x, y
end

-- id1 and id2 : direction
-- id3 : start point
-- d : distance
function extendPoint(landmarks, id1, id2, id3, d)
    local x1, y1 = landmarks[id1 * 2 + 1], landmarks[id1 * 2 + 2]
    local x2, y2 = landmarks[id2 * 2 + 1], landmarks[id2 * 2 + 2]
    local x3, y3 = landmarks[id3 * 2 + 1], landmarks[id3 * 2 + 2]
    local len = math.sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2))
    local x = x3 + ((x2 - x1) / len) * d
    local y = y3 + ((y2 - y1) / len) * d
    return x, y
end

function distanceTwoPoints(landmarks, id1, id2)
    local x1, y1 = landmarks[id1 * 2 + 1], landmarks[id1 * 2 + 2]
    local x2, y2 = landmarks[id2 * 2 + 1], landmarks[id2 * 2 + 2]
    local len = math.sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2))
    return len
end

function fillLandmark(landmarks, data)
    for i = 1, #Config.ValidIndices do
        local idx = Config.ValidIndices[i]
        landmarks[idx * 2 + 1] = data[2 * (i - 1) + 1] / 255
        landmarks[idx * 2 + 2] = data[2 * (i - 1) + 2] / 255
    end

    landmarks[85 * 2 + 1], landmarks[85 * 2 + 2] = segmentPoint(landmarks, 84, 87, 3, 1)
    landmarks[86 * 2 + 1], landmarks[86 * 2 + 2] = segmentPoint(landmarks, 84, 87, 3, 2)
    landmarks[88 * 2 + 1], landmarks[88 * 2 + 2] = segmentPoint(landmarks, 87, 90, 3, 1)
    landmarks[89 * 2 + 1], landmarks[89 * 2 + 2] = segmentPoint(landmarks, 87, 90, 3, 2)
    landmarks[91 * 2 + 1], landmarks[91 * 2 + 2] = segmentPoint(landmarks, 90, 93, 3, 1)
    landmarks[92 * 2 + 1], landmarks[92 * 2 + 2] = segmentPoint(landmarks, 90, 93, 3, 2)
    landmarks[94 * 2 + 1], landmarks[94 * 2 + 2] = segmentPoint(landmarks, 93, 84, 3, 1)
    landmarks[95 * 2 + 1], landmarks[95 * 2 + 2] = segmentPoint(landmarks, 93, 84, 3, 2)
    landmarks[96 * 2 + 1], landmarks[96 * 2 + 2] = landmarks[84 * 2 + 1], landmarks[84 * 2 + 2]
    landmarks[98 * 2 + 1], landmarks[98 * 2 + 2] = midPoint(landmarks, 84, 90)
    landmarks[100 * 2 + 1], landmarks[100 * 2 + 2] = landmarks[90 * 2 + 1], landmarks[90 * 2 + 2]
    landmarks[102 * 2 + 1], landmarks[102 * 2 + 2] = midPoint(landmarks, 84, 90)
    
    landmarks[97 * 2 + 1], landmarks[97 * 2 + 2] = segmentPoint(landmarks, 98, 84, 3, 1)
    landmarks[99 * 2 + 1], landmarks[99 * 2 + 2] = segmentPoint(landmarks, 98, 90, 3, 1)

    landmarks[103 * 2 + 1], landmarks[103 * 2 + 2] = segmentPoint(landmarks, 102, 84, 3, 1)
    landmarks[101 * 2 + 1], landmarks[101 * 2 + 2] = segmentPoint(landmarks, 102, 90, 3, 1)

    landmarks[49 * 2 + 1], landmarks[49 * 2 + 2] = midPoint(landmarks, 82, 83)
    landmarks[47 * 2 + 1], landmarks[47 * 2 + 2] = segmentPoint(landmarks, 82, 49, 3, 1)
    landmarks[48 * 2 + 1], landmarks[48 * 2 + 2] = segmentPoint(landmarks, 82, 49, 3, 2)
    landmarks[50 * 2 + 1], landmarks[50 * 2 + 2] = segmentPoint(landmarks, 49, 83, 3, 1)
    landmarks[51 * 2 + 1], landmarks[51 * 2 + 2] = segmentPoint(landmarks, 49, 83, 3, 2)
    
    landmarks[43 * 2 + 1], landmarks[43 * 2 + 2] = midPoint(landmarks, 55, 58)

    landmarks[0 * 2 + 1], landmarks[0 * 2 + 2] = landmarks[1 * 2 + 1], landmarks[1 * 2 + 2]
    landmarks[32 * 2 + 1], landmarks[32 * 2 + 2] = landmarks[31 * 2 + 1], landmarks[31 * 2 + 2]

    for i = 1, 3 do
        landmarks[(1+i) * 2 + 1], landmarks[(1+i) * 2 + 2] = segmentPoint(landmarks, 1, 5, 4, i)
        landmarks[(27+i) * 2 + 1], landmarks[(27+i) * 2 + 2] = segmentPoint(landmarks, 27, 31, 4, i)
    end

    for i = 1, 4 do
        landmarks[(5+i) * 2 + 1], landmarks[(5+i) * 2 + 2] = segmentPoint(landmarks, 5, 10, 5, i)
        landmarks[(22+i) * 2 + 1], landmarks[(22+i) * 2 + 2] = segmentPoint(landmarks, 22, 27, 5, i)
    end

    for i = 1, 5 do
        landmarks[(10+i) * 2 + 1], landmarks[(10+i) * 2 + 2] = segmentPoint(landmarks, 10, 16, 6, i)
        landmarks[(16+i) * 2 + 1], landmarks[(16+i) * 2 + 2] = segmentPoint(landmarks, 16, 22, 6, i)
    end
    
    landmarks[53 * 2 + 1], landmarks[53 * 2 + 2] = midPoint(landmarks, 52, 72)
    landmarks[54 * 2 + 1], landmarks[54 * 2 + 2] = midPoint(landmarks, 55, 72)
    landmarks[57 * 2 + 1], landmarks[57 * 2 + 2] = midPoint(landmarks, 52, 73)
    landmarks[56 * 2 + 1], landmarks[56 * 2 + 2] = midPoint(landmarks, 55, 73)

    landmarks[59 * 2 + 1], landmarks[59 * 2 + 2] = midPoint(landmarks, 58, 75)
    landmarks[60 * 2 + 1], landmarks[60 * 2 + 2] = midPoint(landmarks, 61, 75)
    landmarks[63 * 2 + 1], landmarks[63 * 2 + 2] = midPoint(landmarks, 58, 76)
    landmarks[62 * 2 + 1], landmarks[62 * 2 + 2] = midPoint(landmarks, 61, 76)
end

function fillExtPoint(landmarks)
    local minx, maxx, miny, maxy = calcShapeBoundingBox(Config.IgnoeIdices, landmarks)
    print("fillExtPoint")
    print(minx, maxx, miny, maxy)
    local dx = (maxx - minx) / 10
    local dy = (maxy - miny) / 10

    Config.FaceExtPoint[2 * 0 + 1], Config.FaceExtPoint[2 * 0 + 2] = extendPoint(landmarks, 16, 93, 0, 6 * dy) -- 106
    Config.FaceExtPoint[2 * 1 + 1], Config.FaceExtPoint[2 * 1 + 2] = extendPoint(landmarks, 16, 93, 72, 7 * dy) -- 107
    Config.FaceExtPoint[2 * 2 + 1], Config.FaceExtPoint[2 * 2 + 2] = extendPoint(landmarks, 16, 93, 49, 11 * dy) -- 108
    Config.FaceExtPoint[2 * 3 + 1], Config.FaceExtPoint[2 * 3 + 2] = extendPoint(landmarks, 16, 93, 75, 7 * dy) -- 109
    Config.FaceExtPoint[2 * 4 + 1], Config.FaceExtPoint[2 * 4 + 2] = extendPoint(landmarks, 16, 93, 32, 6 * dy) -- 110

    -- 111 ~ 143
    for i = 0, 32 do
        Config.FaceExtPoint[2 * (5 + i) + 1], Config.FaceExtPoint[2 * (5 + i) + 2] = extendPoint(landmarks, 49, i, i, 3 * dy)
    end

    -- 144 ~ 148
    Config.FaceExtPoint[2 * 38 + 1], Config.FaceExtPoint[2 * 38 + 2] = extendPoint(landmarks, 16, 93, 0,  4 * dy + 4 * dy) -- 144
    Config.FaceExtPoint[2 * 39 + 1], Config.FaceExtPoint[2 * 39 + 2] = extendPoint(landmarks, 16, 93, 72, 5 * dy + 4 * dy) -- 145
    Config.FaceExtPoint[2 * 40 + 1], Config.FaceExtPoint[2 * 40 + 2] = extendPoint(landmarks, 16, 93, 49, 9 * dy + 4 * dy) -- 146
    Config.FaceExtPoint[2 * 41 + 1], Config.FaceExtPoint[2 * 41 + 2] = extendPoint(landmarks, 16, 93, 75, 5 * dy + 4 * dy) -- 147
    Config.FaceExtPoint[2 * 42 + 1], Config.FaceExtPoint[2 * 42 + 2] = extendPoint(landmarks, 16, 93, 32, 4 * dy + 4 * dy) -- 148
end

function rotateFaceLandmark(landmarks, extLandmarks, x, y, z)
    local midpnt_x, midpnt_y = midPoint(landmarks, 55, 58)
    local rotMat = Matrix4f:RotMat(x, y, z)

    local lm = table_copy(landmarks)
    for i = 1, #lm / 2 do
        local vec1 = Vec3f.new(lm[2 * (i - 1) + 1], -lm[2 * (i - 1) + 2], 0.0)
        local vec2 = rotMat * Matrix4f:TransMat(-midpnt_x, midpnt_y, 0.0) * vec1
        local vec3 = Matrix4f:TransMat(midpnt_x, -midpnt_y, 0.0) * vec2
        landmarks[2 * (i - 1) + 1], landmarks[2 * (i - 1) + 2] = vec3.x, -vec3.y
    end

    for i = 1, 5 do
        local vec1 = Vec3f.new(extLandmarks[2 * (i - 1) + 1], -extLandmarks[2 * (i - 1) + 2], 0.0)
        local vec2 = rotMat * Matrix4f:TransMat(-midpnt_x, midpnt_y, 0.0) * vec1
        local vec3 = Matrix4f:TransMat(midpnt_x, -midpnt_y, 0.0) * vec2
        extLandmarks[2 * (i - 1) + 1], extLandmarks[2 * (i - 1) + 2] = vec3.x, -vec3.y
    end
end

function clampValue(v, min, max)
    if v > max then return max
    elseif v < min then return min
    else return v
    end
end

function initParams(context, filter)
    OF_LOGI(TAG, "call initParams")
    filter:insertResParam("TargetPhoto", OF_ResType_Image, "target.png")
    filter:insertBoolParam("Avatar", true)
    filter:insertFloatParam("OpenMouth", 0.0, 1.0, 0.0)
    filter:insertFloatParam("CloseLeftEye", 0.0, 1.0, 0.0)
    filter:insertFloatParam("CloseRightEye", 0.0, 1.0, 0.0)
    filter:insertFloatParam("RotX", -20, 20, 0);
    filter:insertFloatParam("RotY", -20, 20, 0);
    filter:insertFloatParam("RotZ", -20, 20, 0);
    return OF_Result_Success
end

function initRenderer(context, filter)
    OF_LOGI(TAG, "call initRenderer")

    local pngPath = filter:resFullPath(filter:resParam("TargetPhoto"))
    _faceTexture = context:loadTexture(pngPath)
    print(pngPath)

    _renderPass = context:createCustomShaderPass(vs, fs)
    
    FaceLandmark:init(context)

    local minx, maxx, miny, maxy = calcBoundingBox(Config.IgnoeIdices)
    print(minx, maxx, miny, maxy)

    for i = 1, #Config.ExperShapes do
        Config.ExperShapes[i].delta = getBlendshape(Config.BaseShape, Config.ExperShapes[i], minx, maxx, miny, maxy)
    end

    return OF_Result_Success
end

function teardownRenderer(context, filter)
    OF_LOGI(TAG, "call teardownRenderer")
    context:destroyCustomShaderPass(_renderPass)
    if _faceVbo then
	    context:destroyBuffer(_faceVbo)
	    context:destroyBuffer(_faceIbo)
	end
    _faceVbo = nil
    _faceIbo = nil
    _faceVertexBuffer = nil

    context:destroyTexture(_faceTexture)

    FaceLandmark:teardown()
    return OF_Result_Success
end

function applyRGBA(context, filter, frameData, inTex, outTex, debugTex)
    local frequencyData = frameData.audioFrameData.frequencyData
    if frequencyData[1] > 0 and _faceVbo == nil then
        print("init vbo and ibo")
        fillLandmark(Config.FaceLandmark, frequencyData)
        fillExtPoint(Config.FaceLandmark)
    
        _faceVertexBuffer = FloatArray.new(4 * (FacePointCount + ExtPointCount))
        fillVertexBuffer(_faceVertexBuffer, Config.FaceLandmark, Config.FaceLandmark, Config.FaceExtPoint, Config.FaceExtPoint)
        _faceVbo = context:createVertexBuffer(_faceVertexBuffer, DYNAMIC_DRAW)
    
        local indexCount = #Config.FaceIndices
        local indexBuffer = Uint16Array.new(indexCount)
        for i = 1, indexCount do
            indexBuffer:set(i - 1, Config.FaceIndices[i])
        end
        _faceIbo = context:createIndexBuffer(indexBuffer, STATIC_DRAW)
    end

    if _faceVbo then
        local faceData = frameData.faceFrameDataArr.faceItemArr[1]
        local faceCount = frameData.faceFrameDataArr.faceCount
        print("isMouthOpen", faceData.isMouthOpen)
        print("face count", frameData.faceFrameDataArr.faceCount)

        local mat = Matrix4f.new()
        mat:set(faceData.faceMesh.modelViewMat)
        local rot = mat:getRot()
        --OF_LOGI(TAG, string.format("rot : %.2f, %.2f, %.2f", rot.x, rot.y, rot.z))
        OF_LOGI(TAG, string.format("rot : %.2f, %.2f, %.2f", rot.x * 180 / math.pi, rot.y * 180 / math.pi, rot.z * 180 / math.pi))

        local openMouthWeight = 0.0
        local closeLeftEyeWeight = 0.0
        local closeRightEyeWeight = 0.0
        if not filter:boolParam("Avatar") then
            openMouthWeight = filter:floatParam("OpenMouth")
            closeLeftEyeWeight = filter:floatParam("CloseLeftEye")
            closeRightEyeWeight = filter:floatParam("CloseRightEye")
        elseif faceCount > 0 then
            local a = distanceTwoPoints(faceData.facePoints, 93, 87)
            local b = distanceTwoPoints(faceData.facePoints, 84, 90)
            local openMouthIntensity = a / b * 0.5;
            print("openMouthIntensity", openMouthIntensity)
            
            local w = (openMouthIntensity - 0.5) / 0.4
            if w < 0.0 then w = 0.0 end

            openMouthWeight = w --faceData.blendshapeWeightMap[25]
            closeLeftEyeWeight = faceData.blendshapeWeightMap[10]
            closeRightEyeWeight = faceData.blendshapeWeightMap[9]
        end

        local weights = { openMouthWeight, closeLeftEyeWeight, closeRightEyeWeight }
        local landmark106 = generateNewShape(Config.FaceLandmark, weights)

        local extPoints = table_copy(Config.FaceExtPoint)

        if filter:boolParam("Avatar") then
            rotateFaceLandmark(landmark106, extPoints, 
                clampValue(rot.x, -math.pi * 20 / 180.0, math.pi * 20 / 180.0),
                clampValue(rot.y, -math.pi * 20 / 180.0, math.pi * 20 / 180.0),
                clampValue(rot.z / 3, -math.pi * 5 / 180.0, math.pi * 5 / 180.0))
        else
            rotateFaceLandmark(landmark106, extPoints,
                filter:floatParam("RotX") * math.pi / 180.0, 
                filter:floatParam("RotY") * math.pi / 180.0,
                filter:floatParam("RotZ") * math.pi / 180.0)
        end

        fillVertexBuffer(_faceVertexBuffer, landmark106, nil, extPoints, nil)
        _faceVbo:updateFloatArrayOffset(0, _faceVertexBuffer, 0, (FacePointCount + ExtPointCount) * FloatPerVertex)

        -- render
        context:copyTexture(inTex, outTex)
        context:setViewport(0, 0, outTex.width, outTex.height)
            
        context:bindFBO(outTex)
        context:setClearColor(0, 0, 0, 1)
        context:clearColorBuffer()

        context:setBlend(false)
        context:setCullFace(RS_CullMode_None)
        context:setDepthMask(false)
        context:setDepthTest(false)
        context:setDepthFunc(RS_DepthFunc_LESS_EQUAL)
        
        _renderPass:use()
        _renderPass:setUniformTexture("uTexture", 0, _faceTexture:toOFTexture().textureID, TEXTURE_2D)
        
        -- draw face mesh
        _faceVbo:bind()
        local stride = FloatPerVertex * 4
        _renderPass:setVertexAttrib("aPosition", 2, FLOAT, 0, stride, 0)
        _renderPass:setVertexAttrib("aTextureCoord", 2, FLOAT, 0, stride, 2 * 4)
        _faceIbo:bind()
        _renderPass:drawElements(TRIANGLES,  #Config.FaceIndices, UNSIGNED_SHORT, 0)

        FaceLandmark:draw(faceData, frameData.timestamp, outTex, landmark106)
    else
        context:copyTexture(inTex, outTex)
    end

    if debugTex then
        if frameData.faceFrameDataArr.faceCount > 0 then
            local faceData = frameData.faceFrameDataArr.faceItemArr[1]
            FaceLandmark:draw(faceData, frameData.timestamp, debugTex, Config.FaceLandmark)
        end
    end
    return OF_Result_Success
end

function requiredFrameData(context, game)
    return { OF_RequiredFrameData_FaceLandmarker, OF_RequiredFrameData_HeadPoseEstimate, OF_RequiredFrameData_Avatar, OF_RequiredFrameData_AudioBeat }
end

function onApplyParams(context, filter)
    OF_LOGI(TAG, "call onApplyParams")
    local pngName = filter:resParam("TargetPhoto")
    print(pngName)
    return OF_Result_Success
end

function readObject(context, filter, archiveIn)
    OF_LOGI(TAG, "call readObject")
    return OF_Result_Success
end

function writeObject(context, filter, archiveOut)
    OF_LOGI(TAG, "call writeObject")
    return OF_Result_Success
end
