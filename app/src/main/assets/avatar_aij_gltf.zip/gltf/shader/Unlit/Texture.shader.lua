vs = [[
    uniform mat4 uMVP;

    attribute vec4 aPosition;
    attribute vec2 aTextureCoord;

    varying vec2 vUV;

    void main()
    {
        gl_Position = uMVP * aPosition;
        vUV = aTextureCoord;
    }
]]

fs = [[
    precision highp float;

    uniform sampler2D _MainTex;

    varying vec2 vUV;

    void main()
    {
        gl_FragColor = texture2D(_MainTex, vUV);
    }
]]

--[[
    Cull
	    Back | Front | Off
    ZTest
	    Less | Greater | LEqual | GEqual | Equal | NotEqual | Always
    ZWrite
	    On | Off
    Blend
	    Off / SrcBlendMode DstBlendMode
	    One Zero SrcColor SrcAlpha DstColor DstAlpha OneMinusSrcColor OneMinusSrcAlpha OneMinusDstColor OneMinusDstAlpha
]]

local rs = {
    Cull = Back,
    ZTest = LEqual,
    ZWrite = On,
    Blend = Off,
    SrcBlendMode = SrcAlpha,
    DstBlendMode = OneMinusSrcAlpha,
    Queue = Geometry,
}

local pass = {
    vs = vs,
    fs = fs,
    rs = rs,
}

-- return pass array
return {
    pass
}
