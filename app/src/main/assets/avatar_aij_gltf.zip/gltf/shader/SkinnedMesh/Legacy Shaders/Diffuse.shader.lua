local vs = [[
    uniform mat4 uViewProjectionMatrix;
    uniform vec4 uBones[210];

    attribute vec3 aPosition;
    attribute vec4 aBlendWeight;
    attribute vec4 aBlendIndex;
    attribute vec2 aTextureCoord;
    attribute vec3 aNormal;

    varying vec2 vUV;
    varying vec3 vNormal;

    #define skinned_mesh(mat_out, blend_weight, blend_indices, bones) { \
        int index_0 = int(blend_indices.x);                         \
        int index_1 = int(blend_indices.y);                         \
        int index_2 = int(blend_indices.z);                         \
        int index_3 = int(blend_indices.w);                         \
                                                                    \
        float weights_0 = blend_weight.x;                           \
        float weights_1 = blend_weight.y;                           \
        float weights_2 = blend_weight.z;                           \
        float weights_3 = blend_weight.w;                           \
                                                                    \
        mat4 bone_0 = mat4(bones[index_0*3], bones[index_0*3+1], bones[index_0*3+2], vec4(0, 0, 0, 1));     \
        mat4 bone_1 = mat4(bones[index_1*3], bones[index_1*3+1], bones[index_1*3+2], vec4(0, 0, 0, 1));     \
        mat4 bone_2 = mat4(bones[index_2*3], bones[index_2*3+1], bones[index_2*3+2], vec4(0, 0, 0, 1));     \
        mat4 bone_3 = mat4(bones[index_3*3], bones[index_3*3+1], bones[index_3*3+2], vec4(0, 0, 0, 1));     \
        mat4 bone = bone_0 * weights_0 + bone_1 * weights_1 + bone_2 * weights_2 + bone_3 * weights_3;      \
                                                                                                            \
        mat_out = bone;                                                                                     \
    }

    void main()
    {
        mat4 worldMatrix;
        skinned_mesh(worldMatrix, aBlendWeight, aBlendIndex, uBones);

        gl_Position = uViewProjectionMatrix * (vec4(aPosition, 1.0) * worldMatrix);
        vUV = aTextureCoord;
        vNormal = (vec4(aNormal, 0) * worldMatrix).xyz;
    }
]]

local fs = [[
    precision highp float;

    uniform sampler2D _MainTex;
    uniform vec4 _Color;
    uniform vec4 uLightColor;
    uniform vec4 uLightDir;

    varying vec2 vUV;
    varying vec3 vNormal;

    void main()
    {
        vec4 c = texture2D(_MainTex, vUV) * _Color;
        float nl = dot(normalize(vNormal), normalize(-uLightDir.xyz));
        c.rgb = c.rgb * uLightColor.rgb * nl;
        gl_FragColor = c;
    }
]]

--[[
    Cull
	    Back | Front | Off
    ZTest
	    Less | Greater | LEqual | GEqual | Equal | NotEqual | Always
    ZWrite
	    On | Off
    Blend
	    Off / SrcBlendMode DstBlendMode
	    One Zero SrcColor SrcAlpha DstColor DstAlpha OneMinusSrcColor OneMinusSrcAlpha OneMinusDstColor OneMinusDstAlpha
]]

local rs = {
    Cull = Back,
    ZTest = LEqual,
    ZWrite = On,
    Blend = Off,
    SrcBlendMode = SrcAlpha,
    DstBlendMode = OneMinusSrcAlpha,
    Queue = Geometry,
}

local pass = {
    vs = vs,
    fs = fs,
    rs = rs,
}

-- return pass array
return {
    pass
}
