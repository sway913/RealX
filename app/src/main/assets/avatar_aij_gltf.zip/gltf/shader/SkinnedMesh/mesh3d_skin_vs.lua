vs = [[
    uniform mat4 uViewMatrix;
    uniform mat4 uProjectionMatrix;
    uniform vec4 uBones[210];
    uniform vec4 _Time;
    uniform float _FrameCount;
    uniform float _FrameX;
    uniform float _FrameY;
    uniform float _FrameRate;
    uniform vec4 _OffsetSpeed;

    attribute vec4 aPosition;
    attribute vec2 aTextureCoord;
    attribute vec3 aNormal;
    attribute vec4 aTangent;
    attribute vec4 aBlendWeight;
    attribute vec4 aBlendIndex;

    varying vec2 vUV;
    varying vec4 vTSpace0;
    varying vec4 vTSpace1;
    varying vec4 vTSpace2;

    #define skinned_mesh(mat_out, blend_weight, blend_indices, bones) { \
        int index_0 = int(blend_indices.x);                             \
        int index_1 = int(blend_indices.y);                             \
        int index_2 = int(blend_indices.z);                             \
        int index_3 = int(blend_indices.w);                             \
                                                                        \
        float weights_0 = blend_weight.x;                               \
        float weights_1 = blend_weight.y;                               \
        float weights_2 = blend_weight.z;                               \
        float weights_3 = blend_weight.w;                               \
                                                                        \
        mat4 bone_0 = mat4(bones[index_0*3], bones[index_0*3+1], bones[index_0*3+2], vec4(0, 0, 0, 1));     \
        mat4 bone_1 = mat4(bones[index_1*3], bones[index_1*3+1], bones[index_1*3+2], vec4(0, 0, 0, 1));     \
        mat4 bone_2 = mat4(bones[index_2*3], bones[index_2*3+1], bones[index_2*3+2], vec4(0, 0, 0, 1));     \
        mat4 bone_3 = mat4(bones[index_3*3], bones[index_3*3+1], bones[index_3*3+2], vec4(0, 0, 0, 1));     \
        mat4 bone = bone_0 * weights_0 + bone_1 * weights_1 + bone_2 * weights_2 + bone_3 * weights_3;      \
                                                                                                            \
        mat_out = bone;                                                                                     \
    }

    void main()
    {
        mat4 worldMatrix;
        skinned_mesh(worldMatrix, aBlendWeight, aBlendIndex, uBones);

        // transpose
        {
            float temp = worldMatrix[0][1];
            worldMatrix[0][1] = worldMatrix[1][0];
            worldMatrix[1][0] = temp;

            temp = worldMatrix[0][2];
            worldMatrix[0][2] = worldMatrix[2][0];
            worldMatrix[2][0] = temp;

            temp = worldMatrix[0][3];
            worldMatrix[0][3] = worldMatrix[3][0];
            worldMatrix[3][0] = temp;

            temp = worldMatrix[1][2];
            worldMatrix[1][2] = worldMatrix[2][1];
            worldMatrix[2][1] = temp;

            temp = worldMatrix[1][3];
            worldMatrix[1][3] = worldMatrix[3][1];
            worldMatrix[3][1] = temp;

            temp = worldMatrix[2][3];
            worldMatrix[2][3] = worldMatrix[3][2];
            worldMatrix[3][2] = temp;
        }

        mat4 worldViewMatrix = uViewMatrix * worldMatrix;
        vec4 posView = worldViewMatrix * aPosition;

        gl_Position = uProjectionMatrix * posView;
        
        if (int(_FrameCount) > 1)
	    {
		    int frame = int(_Time.y * _FrameRate);
		    frame = frame - (frame / int(_FrameCount)) * int(_FrameCount);
		    int x = frame - (frame / int(_FrameX)) * int(_FrameX);
		    int y = frame / int(_FrameX);
		    float w = 1.0 / float(_FrameX);
		    float h = 1.0 / float(_FrameY);

		    vec4 scale_offset;
		    scale_offset.x = w;
		    scale_offset.y = h;
		    scale_offset.z = float(x) * w;
		    scale_offset.w = float(y) * h;

		    vUV = aTextureCoord * scale_offset.xy + scale_offset.zw;
	    }
	    else
	    {
		    vUV = aTextureCoord;
	    }

        vUV += _OffsetSpeed.xy * _Time.y;

        vec3 normal = normalize((vec4(aNormal, 0) * worldViewMatrix).xyz);
	    vec3 tangent = normalize((vec4(aTangent.xyz, 0) * worldViewMatrix).xyz);
	    vec3 binormal = normalize(cross(normal, tangent) * aTangent.w);

	    vTSpace0 = vec4(tangent.x, binormal.x, normal.x, posView.x);
	    vTSpace1 = vec4(tangent.y, binormal.y, normal.y, posView.y);
	    vTSpace2 = vec4(tangent.z, binormal.z, normal.z, posView.z);
    }
]]
