return {
    FaceAction = 
    {
        { name = "browDownLeft",        shapeIdx = { 15} },  -- 0
        { name = "browDownRight",       shapeIdx = { 14} },  -- 1
        { name = "browInnerUp",         shapeIdx = { 16} },  -- 2
        { name = "browOuterUpLeft",     shapeIdx = { 18} },  -- 3
        { name = "browOuterUpRight",    shapeIdx = { 17} },  -- 4
        { name = "cheekPuff",           shapeIdx = { 19} },  -- 5
        { name = "cheekSquintLeft",     shapeIdx = { 21} },  -- 6
        { name = "cheekSquintRight",    shapeIdx = { 20} },  -- 7
        { name = "eyeBlinkLeft",        shapeIdx = {  1} },  -- 8
        { name = "eyeBlinkRight",       shapeIdx = {  0} },   -- 9
        { name = "eyeLookDownLeft",     shapeIdx = {  3} },   -- 10
        { name = "eyeLookDownRight",    shapeIdx = {  2} },   -- 11
        { name = "eyeLookInLeft",       shapeIdx = {  5} },   -- 12
        { name = "eyeLookInRight",      shapeIdx = {  4} },   -- 13
        { name = "eyeLookOutLeft",      shapeIdx = {  7} },   -- 14
        { name = "eyeLookOutRight",     shapeIdx = {  6} },   -- 15
        { name = "eyeLookUpLeft",       shapeIdx = {  9} },   -- 16
        { name = "eyeLookUpRight",      shapeIdx = {  8} },   -- 17
        { name = "eyeSquintLeft",       shapeIdx = { 11} },   -- 18
        { name = "eyeSquintRight",      shapeIdx = { 10} },   -- 19
        { name = "eyeWideLeft",         shapeIdx = { 13} },   -- 20
        { name = "eyeWideRight",        shapeIdx = { 12} },   -- 21
        { name = "jawForward",          shapeIdx = {  } },   -- 22
        { name = "jawLeft",             shapeIdx = {  } },  -- 23
        { name = "jawOpen",             shapeIdx = {  } },  -- 24
        { name = "jawRight",            shapeIdx = {  } },  -- 25
        { name = "mouthClose",          shapeIdx = {  } },   -- 26
        { name = "mouthDimpleLeft",     shapeIdx = { 33} },   -- 27
        { name = "mouthDimpleRight",    shapeIdx = { 32} },   -- 28
        { name = "mouthFrownLeft",      shapeIdx = { 31} },   -- 29
        { name = "mouthFrownRight",     shapeIdx = { 30} },   -- 30
        { name = "mouthFunnel",         shapeIdx = { 24} },  -- 31
        { name = "mouthLeft",           shapeIdx = { 27} },   -- 32
        { name = "mouthLowerDownLeft",  shapeIdx = { 43} },  -- 33
        { name = "mouthLowerDownRight", shapeIdx = { 42} },  -- 34
        { name = "mouthPressLeft",      shapeIdx = { 41} },   -- 35
        { name = "mouthPressRight",     shapeIdx = { 40} },   -- 36
        { name = "mouthPucker",         shapeIdx = { 25} },  -- 37
        { name = "mouthRight",          shapeIdx = { 26} },   -- 38
        { name = "mouthRollLower",      shapeIdx = { 36} },   -- 39
        { name = "mouthRollUpper",      shapeIdx = { 37} },   -- 40
        { name = "mouthShrugLower",     shapeIdx = { 38} },   -- 41
        { name = "mouthShrugUpper",     shapeIdx = { 39} },   -- 42
        { name = "mouthSmileLeft",      shapeIdx = { 29} },  -- 43
        { name = "mouthSmileRight",     shapeIdx = { 28} },  -- 44
        { name = "mouthStretchLeft",    shapeIdx = { 34} },  -- 45
        { name = "mouthStretchRight",   shapeIdx = { 35} },  -- 46
        { name = "mouthUpperUpLeft",    shapeIdx = { 45} },  -- 47
        { name = "mouthUpperUpRight",   shapeIdx = { 44} },  -- 48
        { name = "noseSneerLeft",       shapeIdx = { 22} },  -- 49
        { name = "noseSneerRight",      shapeIdx = { 23} },  -- 50
    },
    ShowLandmarks = true,
}
