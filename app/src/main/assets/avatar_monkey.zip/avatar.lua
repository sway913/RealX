TAG = "OF-AvatarMonkey"
local Config = require("config")

local avatar = nil
local point_render = nil
local point_program = nil
local point_array = nil
local point_color_array = nil
local point_array_count = 106
local avatar_point_render = nil
local avatar_point_array = nil
local avatar_point_color_array = nil
local PI = 3.1415926
local Pt68To106 = {
    0, 2, 4, 6, 8, 10, 12, 14, 16, 18,
    20, 22, 24, 26, 28, 30, 32, 33, 34, 35,
    36, 37, 38, 39, 40, 41, 42, 43, 44, 45,
    46, 47, 48, 49, 50, 51, 52, 53, 54, 55,
    56, 57, 58, 59, 60, 61, 62, 63, 84, 85,
    86, 87, 88, 89, 90, 91, 92, 93, 94, 95,
    96, 97, 98, 99, 100, 101, 102, 103, 68, 69,
    70, 71, 72 }
    
local FaceVertexIdx = {
    33, 225, 229, 233, 2086, 157, 590, 2091, 666, 662,
    658, 2774, 379, 272, 114, 101, 2794, 270, 2797, 1567,
    2449, 175, 2661, 181, 1462, 176, 614, 613, 608, 2452,
    609, 611, 3307, 3086, 3302, 3404, 3304, 3089, 3309, 841,
    693, 411, 264, 3273, 3211, 423, 3212, 3119, 442, 3115 }
    
local FaceVertexIdx = {
    0, 1, 2, 3, 4, 5, 6, 7, 8, 9,
    10, 11, 12, 13, 14, 15, 16, 17, 18, 19,
    20, 21, 22, 23, 24, 25, 26, 27, 28, 29,
    30, 31, 32, 33, 34, 35, 36, 37, 38, 39,
    40, 41, 42, 43, 44, 45, 46, 47, 48, 49 }
    
local FaceLandmarkIdx = {
     8, 17, 18, 19, 20, 21, 22, 23, 24, 25,
    26, 27, 28, 29, 30, 31, 32, 33, 34, 35,
    36, 37, 38, 39, 40, 41, 42, 43, 44, 45,
    46, 47, 48, 49, 50, 51, 52, 53, 54, 55,
    56, 57, 58, 59, 61, 62, 63, 65, 66, 67 }

function initRenderer(context, filter)
    local modelPath = filter:resDir() .. "/model/monkey.ofmodel"
    avatar = context:createRendererTreeNode()
    avatar:loadModel(modelPath)
    avatar:setScale(1)
    OF_LOGI(TAG, string.format("%s", modelPath))
    
    local bbox = avatar:getBoundingBox()
    OF_LOGI(TAG, string.format("min(%f, %f, %f)  max(%f, %f, %f)", bbox.min.x, bbox.min.y, bbox.min.z, bbox.max.x, bbox.max.y, bbox.max.z))
    
    initPoints(context)
    
    return OF_Result_Success
end

function initPoints(context)
    local VS = [[
        attribute vec4 aPosition;
        attribute vec4 aColor;
        varying vec4 vColor;
        void main()
        {
            gl_PointSize = 3.0;
            gl_Position = aPosition;
            vColor = aColor;
        }
        ]]

    local FS = [[
        precision mediump float;
        varying vec4 vColor;
        void main()
        {
            gl_FragColor = vColor;
        }
    ]]
    if point_program == nil then
        point_program = context:createCustomShaderPass(VS, FS)
    end
    
    if point_render == nil then
        local pointCount = point_array_count
        point_array = FloatArray.new(pointCount * 2)
        point_color_array = FloatArray.new(pointCount * 4)
        
        for i = 1, pointCount do
            point_array:set((i - 1) * 2, 0.0)
            point_array:set((i - 1) * 2 + 1, 0.0)

            -- point color
            point_color_array:set((i - 1) * 4 + 0, 0)
            point_color_array:set((i - 1) * 4 + 1, 1)
            point_color_array:set((i - 1) * 4 + 2, 0)
            point_color_array:set((i - 1) * 4 + 3, 1)
        end
        
        point_render = PointSprite2DRender.new(point_array, pointCount)
        point_render:updateColors(point_color_array, pointCount)
    end
    
    if avatar_point_render == nil then
        local pointCount = 50
        avatar_point_array = FloatArray.new(pointCount * 2)
        avatar_point_color_array = FloatArray.new(pointCount * 4)
        for i = 1, pointCount do
            avatar_point_array:set((i - 1) * 2, 0.0)
            avatar_point_array:set((i - 1) * 2 + 1, 0.0)
            
            -- point color
            avatar_point_color_array:set((i - 1) * 4 + 0, 1)
            avatar_point_color_array:set((i - 1) * 4 + 1, 0)
            avatar_point_color_array:set((i - 1) * 4 + 2, 0)
            avatar_point_color_array:set((i - 1) * 4 + 3, 1)
        end
        
        avatar_point_render = PointSprite2DRender.new(avatar_point_array, pointCount)
        avatar_point_render:updateColors(avatar_point_color_array, pointCount)
    end
end

function updatePoints(context, pnts, pointCount)
    for i = 1, pointCount do
        local idx = i--Pt68To106[i] + 1
        point_array:set((i - 1) * 2, pnts[2*(idx-1)+1] * 2 - 1)
        point_array:set((i - 1) * 2 + 1, pnts[2*(idx-1)+2] * 2 - 1)
        
        -- point color
        point_color_array:set((i - 1) * 4 + 0, 0)
        point_color_array:set((i - 1) * 4 + 1, 1)
        point_color_array:set((i - 1) * 4 + 2, 0)
        point_color_array:set((i - 1) * 4 + 3, 1)
    end
    point_render:updatePoints(point_array, pointCount)
    point_render:updateColors(point_color_array, pointCount)
end

function teardownPoints(context)
    point_render = nil
    point_array = nil
    point_color_array = nil
    
    avatar_point_render = nil
    avatar_point_array = nil
    avatar_point_color_array = nil
    
    context:destroyCustomShaderPass(point_program)
    point_program = nil
end

function updateAvatarPoints(context, pnts, pmat, mvmat)
    local pointCount = 50
    for i = 1, pointCount do
        local modelPnt = Vec4f.new(pnts[FaceVertexIdx[i] * 3 + 1], pnts[FaceVertexIdx[i] * 3 + 2], pnts[FaceVertexIdx[i] * 3 + 3], 1.0)
        local screenPnt = pmat * mvmat * modelPnt
        avatar_point_array:set((i - 1) * 2, screenPnt.x / screenPnt.w)
        avatar_point_array:set((i - 1) * 2 + 1, screenPnt.y / screenPnt.w) 
    end
    avatar_point_render:updatePoints(avatar_point_array, pointCount)
end

function teardownRenderer(context, filter)
    context:destroyRendererTreeNode(avatar)
    teardownPoints(context)
    return OF_Result_Success
end

function distance(x1, y1, x2, y2)
    return math.sqrt((x1 - x2)*(x1 - x2) + (y1 - y2)*(y1 - y2))
end

function showStatistics(context, lm, pnts, pmat, mvmat, width, height)
    local pointCount = 50
    local totalDist = 0.0
    local maxDist = 0.0
    local maxIdx = 0
    for i = 1, pointCount do
        local modelPnt = Vec4f.new(pnts[FaceVertexIdx[i] * 3 + 1], pnts[FaceVertexIdx[i] * 3 + 2], pnts[FaceVertexIdx[i] * 3 + 3], 1.0)
        local screenPnt = pmat * mvmat * modelPnt
        local pixel_x = (0.5 * screenPnt.x / screenPnt.w + 0.5) * width
        local pixel_y = (0.5 * screenPnt.y / screenPnt.w + 0.5) * height
        
        local pixel_lm_x = lm[2*Pt68To106[FaceLandmarkIdx[i]+1]+1] * width
        local pixel_lm_y = lm[2*Pt68To106[FaceLandmarkIdx[i]+1]+2] * height
        
        local dist = distance(pixel_x, pixel_y, pixel_lm_x, pixel_lm_y)
        if dist > maxDist then
            maxDist = dist
            maxIdx = FaceLandmarkIdx[i]
        end
        totalDist = totalDist + dist
    end
    OF_LOGI(TAG, string.format("*****************************"))
    OF_LOGI(TAG, string.format("  Avg Dist : %.3f", totalDist / pointCount))
    OF_LOGI(TAG, string.format("  Max Dist : %.3f, Landmark Id : %d", maxDist, maxIdx))
end

function initParams(context, filter)
    filter:insertFloatParam("TranslateX", -1000.0, 1000.0, 0.0)
    filter:insertFloatParam("TranslateY", -1000.0, 1000.0, -0.0)
    filter:insertFloatParam("TranslateZ", -1000.0, 1000.0, -118.0)
    filter:insertFloatParam("RotateX", -180.0, 180.0, 0.0)
    filter:insertFloatParam("RotateY", -180.0, 180.0, 0.0)
    filter:insertFloatParam("RotateZ", -180.0, 180.0, 0.0)
    filter:insertFloatParam("Scale", 0.01, 1000.0, 188.0)
    filter:insertBoolParam("Show_Face_Mesh", false)
    filter:insertBoolParam("Show_Statistics", false)
end

function onApplyParams(context, filter)
end

function requiredFrameData(context, filter)
    return { OF_RequiredFrameData_FaceLandmarker, OF_RequiredFrameData_HeadPoseEstimate, OF_RequiredFrameData_Avatar }
end

function setBoneRotation(name, x, y, z)
    local bone = avatar:getRootNode():getTransform():find(name)
    local localPosition = bone.localPosition
    local rot = Quaternion.EulerDegree(x, y, z)
    local localScale = bone.localScale
    local mat = Matrix4f.TRS(localPosition, rot, localScale)
    bone:updateTransform(mat)
end

function applyRGBA(context, filter, frameData, inTex, outTex, debugTex)
    local width = outTex.width
    local height = outTex.height
    
    if Config.ShowLandmarks == true then
        context:bindFBO(outTex)
        context:setClearColor(0.3, 0.3, 0.5, 1.0)
        context:clearColorBuffer()
        context:setViewport(0, 0, width/4, height/4)
        
        quadRender = context:sharedQuadRender()
        copyPass = context:sharedCopyPass()
        copyPass:use()
        copyPass:setUniformTexture("uTexture0", 0, inTex.textureID, TEXTURE_2D)
        --quadRender:draw(copyPass, false)
        
        --print(point_array_count)
        -- update and draw the landmarks
        if frameData.faceFrameDataArr.faceCount > 0 then
            local faceData = frameData.faceFrameDataArr.faceItemArr[1]
            if point_array_count ~= faceData.facePointsCount then
                print("reset point render")
                point_array_count = faceData.facePointsCount
                teardownPoints(context)
                initPoints(context)
            end
            updatePoints(context, faceData.facePoints, faceData.facePointsCount)
            context:setBlend(true)
            context:setBlendMode(RS_BlendFunc_SRC_ALPHA, RS_BlendFunc_INV_SRC_ALPHA)
            point_program:use()
            --point_render:draw(point_program, false)
            context:setBlend(false)
        end
        context:setViewport(0, 0, width, height)
    else
        context:copyTexture(inTex, outTex)
    end
    
    context:bindFBOWithSharedDepthTexture(outTex)
    context:setViewport(0, 0, width, height)
    context:clearDepthBuffer()

    local fov = 45
    local aspect = width / height
    local near = 1
    local far = 1000
    local proj = Matrix4f.ReflectMat() * Matrix4f.PerspectiveMat(fov, aspect, near, far)
    context:engine3d():camera():setProjectionMatrix(proj.x)
    context:engine3d():camera():setLookAt(0, 0, 0, 0, 0, -1, 0, 1, 0)

    --
    -- set blendshape weight if any face exists
    --
    local headRot = Vec3f.new()
    if frameData.faceFrameDataArr.faceCount > 0 then
        local faceData = frameData.faceFrameDataArr.faceItemArr[1]
        
        local mat = Matrix4f.new()
        mat:set(faceData.faceMesh.modelViewMat)
        local rot = mat:getRot()
        --OF_LOGI(TAG, string.format("rot : %.2f, %.2f, %.2f", rot.x * 60.0, rot.y * 60.0, rot.z * 60.0))
        
        headRot.x = -1.0 * rot.x
        if rot.y > 0.0 then headRot.y = -PI + rot.y else headRot.y = PI + rot.y end
        if rot.z > 0.0 then headRot.z = PI - rot.z else headRot.z = -PI - rot.z end

        for i = 1, #Config.FaceAction do
            local weight = faceData.blendshapeWeightMap[i] * 100.0
            for idx = 1, #Config.FaceAction[i].shapeIdx do
                local shapeIdx = Config.FaceAction[i].shapeIdx[idx]
                if shapeIdx >= 0 then
                    --print(shapeIdx .. " : " .. weight)
                    avatar:setBlendShapeWeight(shapeIdx, weight)
                end
            end
        end
        
        local w = faceData.blendshapeWeightMap[25]
        if w < 0.2 then w = w / 10
        else w = w * 1.5
        end
        if w > 1.0 then w = 1.0 end
        
        local jawOpen = w * 20.0
        local jawLeft = faceData.blendshapeWeightMap[24] * 15.0
        local jawRight = faceData.blendshapeWeightMap[26] * -15.0
        setBoneRotation("haed/jaw", jawOpen, jawLeft + jawRight, 0.0)
        
        avatar:setRotation(Quaternion.EulerRadians(rot.x + filter:floatParam("RotateX") * PI / 180.0, rot.y + filter:floatParam("RotateY") * PI / 180.0, rot.z + filter:floatParam("RotateZ") * PI / 180.0))
    end
    
    --local blendShapeCount = avatar:getBlendShapeCount()
    --print(blendShapeCount)
    --for i = 0, blendShapeCount-1 do
    --    local blendShapeName = avatar:getBlendShapeName(i)
    --    print(i .. ' : ' .. blendShapeName)
    --end

    avatar:setPosition(Vec3f.new(
        filter:floatParam("TranslateX"),
        filter:floatParam("TranslateY"),
        filter:floatParam("TranslateZ")))
    avatar:setScale(165)
    
    avatar:update(0.0)
    avatar:render(context)

    context:unbindFBOWithDepthBuffer()

    -- debug

    return OF_Result_Success
end

function readObject(context, filter, archiveIn)
end

function writeObject(context, filter, archiveOut)
end
