FaceMesh = {
	_faceTex  = nil,
	_meshPosX = 0.0,
	_meshPosY = 0.0,
	_meshPosZ = 0.0,
	_meshRotX = 0.0,
	_meshRotY = 0.0,
	_meshRotZ = 0.0,
	_meshSize = 1.0,
	_lightIntensity = 0.5
}

local _vsTextureMesh = [[
    uniform mat4 uMVP;
    uniform mat4 uModelViewMatrix;

    attribute vec4 aPosition;
    attribute vec2 aTextureCoord;
    attribute vec3 aNormal;

    varying vec2 vUV;
    varying vec3 vNormal;

    void main()
    {
        gl_Position = uMVP * aPosition;
        vUV = aTextureCoord;
        vNormal = (uModelViewMatrix * vec4(aNormal, 0)).xyz;
    }
]]

local _fsTextureMesh = [[
    precision mediump float;

    uniform sampler2D uTexture;
    uniform vec4 uLightColor;
    uniform vec4 uLightDir;
    uniform float uLightIntensity;

    varying vec2 vUV;
    varying vec3 vNormal;

    void main()
    {
        vec4 c = texture2D(uTexture, vUV);
        float nl = dot(normalize(vNormal), normalize(-uLightDir.xyz));
        c.rgb = c.rgb + c.rgb * uLightColor.rgb * nl * uLightIntensity;
        c.a = 1.0;
        gl_FragColor = c;
    }
]]

local _context = nil
local _program = nil
local _mesh = nil
local _material = nil

function FaceMesh:init(context, modelDir)
	_context = context
	_program = _context:createCustomShaderPass(_vsTextureMesh, _fsTextureMesh)
	_mesh = _context:createRendererTreeNode()
    _mesh:loadModel(modelDir.."/base.ofmodel")
    _material = _mesh:getMaterial()
    _material:replaceProgram(-1, _program)
	self._faceTex = _context:loadTexture(modelDir.."/skin.png")
end

function FaceMesh:teardown()
	_context:destroyRendererTreeNode(_mesh)
    _mesh = nil
    _context:destroyCustomShaderPass(_program)
    _program = nil
end

function FaceMesh:draw(faceFrameData, frameTime, outTex)
	if faceFrameData and outTex and outTex.width > 0 and outTex.height > 0 then
		_context:bindFBOWithSharedDepthTexture(outTex)
		_context:setViewport(0, 0, outTex.width, outTex.height)
		_context:clearDepthBuffer()
		
		_mesh:setPosition(Vec3f.new(self._meshPosX, self._meshPosY, self._meshPosZ))
		_mesh:setRotation(Quaternion.EulerDegree(self._meshRotX, self._meshRotY, self._meshRotZ))
		_mesh:setScale(self._meshSize)
		
		local viewMat = Matrix4f.LookAtMat(Vec3f.new(0, 0, 1),
										   Vec3f.new(0, 0, 0),
										   Vec3f.new(0, 1, 0))
		
		local modelMat = Matrix4f.new()
		modelMat:set(faceFrameData.faceMesh.modelViewMat)

		local projMat = Matrix4f.new()
		projMat:set(faceFrameData.faceMesh.projectionMat)
		projMat = Matrix4f.ScaleMat(1, -1, 1) * projMat

		_mesh:setWorldMatrixExt(modelMat)
		_context:engine3d():camera():setViewMatrix(viewMat.x)
		_context:engine3d():camera():setProjectionMatrix(projMat.x)
		
		local mesh = _mesh:getMesh()
		if mesh:getMeshCount() >= 1 then
			local vertices = faceFrameData.faceMesh.vertices
			local vertexCount = 3448 --#vertices / 3
           
			local mvp = projMat * viewMat * modelMat
			local vertices2 = FloatArray.new(vertexCount * 3)

			--local textureCoords = FloatArray.new(vertexCount * 2)
			for i = 1, vertexCount do
				local x = 0.
				local y = 0.
				-- update texturecoords
				-- local posProj = mvp * Vec4f.new(-vertices[(i - 1) * 3 + 1],
												 -- vertices[(i - 1) * 3 + 2],
												 -- vertices[(i - 1) * 3 + 3],
												 -- 1.0)					
				-- x = (posProj.x / posProj.w + 1.0) * 0.5
				-- y = (posProj.y / posProj.w + 1.0) * 0.5
				-- textureCoords:set((i - 1) * 2 + 0, x)
				-- textureCoords:set((i - 1) * 2 + 1, y)
				
				-- update positions
				x = vertices[(i - 1) * 3 + 1]
				y = vertices[(i - 1) * 3 + 2]
				local z = vertices[(i - 1) * 3 + 3]

				vertices2:set((i - 1) * 3 + 0, x)
				vertices2:set((i - 1) * 3 + 1, y)
				vertices2:set((i - 1) * 3 + 2, z)
			end

			--mesh:updateTextureCoords(0, textureCoords, vertexCount)

            mesh:enableWireframeMode(true)
			mesh:setUpdateVertexScale(Vec3f.new(1, 1, 1))
			mesh:updateVertices(0, vertices2, vertexCount)
			mesh:updateVertexBuffer(0)
		end
		
		if self._faceTex then
			_material:setTextureRef("uTexture", self._faceTex:toOFTexture())
		end
		_material:setVector("uLightColor", Vec4f.new(1, 1, 1, 1))
		_material:setVector("uLightDir", Vec4f.new(0, 0, -1, 0))
		_material:setFloat("uLightIntensity", self._lightIntensity)
		
		_mesh:setFrameTimes(frameTime, 0)
		_mesh:update(0)
		
		_mesh:render(_context)
		
		_context:unbindFBOWithDepthBuffer()
	end
end

return FaceMesh