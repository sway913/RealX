TAG = "OrangeFilter-Avatar(glTF)"

local FaceMesh = require("FaceMesh")
local Config = require("config")
local avatar = nil
local point_render = nil
local point_program = nil
local point_array = nil
local point_color_array = nil

-- local _meshPosX = 0.0
-- local _meshPosY = 0.0
-- local _meshPosZ = 0.0
-- local _meshRotX = 0.0
-- local _meshRotY = 0.0
-- local _meshRotZ = 0.0
-- local _meshSize = 1.0

---------------------------------

local _renderStatesRestorer = nil
local _world = nil
local _camera = nil
local _model = nil

local _orgPos = nil
local _target = nil

-- test params
local _translationEnable = true
local _rotateEnable = false

local _animTimeLength = 1.0
local _translationSpeed = -3
local _rotateSpeed = 0

local _scenePath = "Y_Bear.gltf"
local _targetPath = ""

--local _initPos = Vec3f.new(2, 0, 0)
local _initPos = Vec3f.new(0, 0, 0)
local _initRot = Vec3f.new(0, 0, 0)
local _scale = 1.0

-- camera
local _cameraPos = Vec3f.new(0, 0, 0)
local _cameraRot = Quaternion.EulerDegree(0, 0, 0)

function initRenderer(context, filter)
    print("initRenderer---")

     _renderStatesRestorer = RenderStatesRestorer.new()

    _world = World.Create(context)
    
    -- camera
    _camera = Entity.Create("camera"):addComponentRenderCamera()
    _camera:setClearFlags(OF_CameraClearFlags_DepthOnly)
    _camera:getTransform():setPosition(_cameraPos)
    _camera:getTransform():setRotation(_cameraRot)
    _camera:setFieldOfView(45)
    _camera:setClipNear(1)
    _camera:setClipFar(1000)

    Resources.SetResourceDir(filter:resDir() .. "/gltf")

    _model = Resources.LoadGLTF(_scenePath)
    avatar = _model
    _model:getTransform():setScale(Vec3f.new(1, 1, 1) * _scale)
    _model:getTransform():setPosition(_initPos)
    --_model:getTransform():setRotation(Quaternion.EulerDegree(_initRot.x, _initRot.y, _initRot.z))

    initPoints(context)
    --FaceMesh:init(context, filter:filterDir().."/model")
	
    return OF_Result_Success
end

function initPoints(context)
    local VS = [[
        attribute vec4 aPosition;
        attribute vec4 aColor;
        varying vec4 vColor;
        void main()
        {
            gl_PointSize = 2.0;
            gl_Position = aPosition;
            vColor = aColor;
        }
        ]]

    local FS = [[
        precision mediump float;
        varying vec4 vColor;
        void main()
        {
            gl_FragColor = vColor;
        }
    ]]
    if point_program == nil then
        point_program = context:createCustomShaderPass(VS, FS)
    end
    
    if point_render == nil then
        local pointCount = 106
        point_array = FloatArray.new(pointCount * 2)
        point_color_array = FloatArray.new(pointCount * 4)
        
        for i = 1, pointCount do
            point_array:set((i - 1) * 2, 0.0)
            point_array:set((i - 1) * 2 + 1, 0.0)

            -- point color
            point_color_array:set((i - 1) * 4 + 0, 0)
            point_color_array:set((i - 1) * 4 + 1, 1)
            point_color_array:set((i - 1) * 4 + 2, 0)
            point_color_array:set((i - 1) * 4 + 3, 1)
        end
        
        point_render = PointSprite2DRender.new(point_array, pointCount)
        point_render:updateColors(point_color_array, pointCount)
    end
end

function updatePoints(context, pnts)
    local pointCount = 106
    for i = 1, pointCount do
        point_array:set((i - 1) * 2, pnts[2*(i-1)+1] * 2 - 1)
        point_array:set((i - 1) * 2 + 1, pnts[2*(i-1)+2] * 2 - 1)
        
        -- point color
        point_color_array:set((i - 1) * 4 + 0, 0)
        point_color_array:set((i - 1) * 4 + 1, 1)
        point_color_array:set((i - 1) * 4 + 2, 0)
        point_color_array:set((i - 1) * 4 + 3, 1)
    end
    point_render:updatePoints(point_array, pointCount)
    point_render:updateColors(point_color_array, pointCount)
end

function teardownPoints(context)
    point_render = nil
    context:destroyCustomShaderPass(point_program)
end
 
function teardownRenderer(context, filter)
    print("teardownRenderer-------")

    teardownPoints(context)
	--FaceMesh:teardown()

    _renderStatesRestorer = nil
    World.Destroy(_world)
    _world = nil
    _camera = nil
    _model = nil
	
    return OF_Result_Success
end

function initParams(context, filter)
    filter:insertFloatParam("TranslateX", -100.0, 100.0, 0.0)
    filter:insertFloatParam("TranslateY", -100.0, 100.0, 0.0)
    filter:insertFloatParam("TranslateZ", -100.0, 100.0, 0.0)
    filter:insertFloatParam("RotateX", -180.0, 180.0, 0.0)
    filter:insertFloatParam("RotateY", -180.0, 180.0, 0.0)
    filter:insertFloatParam("RotateZ", -180.0, 180.0, 0.0)
    filter:insertFloatParam("Scale", 0.01, 100.0, 1.0)
	
	-- filter:insertFloatParam("MeshPosX", -300, 300, _meshPosX)
    -- filter:insertFloatParam("MeshPosY", -300, 300, _meshPosY)
    -- filter:insertFloatParam("MeshPosZ", -300, 300, _meshPosZ)
    -- filter:insertFloatParam("MeshRotX", 0.0, 360.0, _meshRotX)
    -- filter:insertFloatParam("MeshRotY", 0.0, 360.0, _meshRotY)
    -- filter:insertFloatParam("MeshRotZ", 0.0, 360.0, _meshRotZ)
    -- filter:insertFloatParam("MeshSize", 0.1, 10.0, _meshSize)
end

function onApplyParams(context, filter)
	-- _meshPosX = filter:floatParam("MeshPosX")
    -- _meshPosY = filter:floatParam("MeshPosY")
    -- _meshPosZ = filter:floatParam("MeshPosZ")
    -- _meshRotX = filter:floatParam("MeshRotX")
    -- _meshRotY = filter:floatParam("MeshRotY")
    -- _meshRotZ = filter:floatParam("MeshRotZ")
    -- _meshSize = filter:floatParam("MeshSize")
end

function requiredFrameData(context, filter)
    --return { OF_RequiredFrameData_FaceLandmarker, OF_RequiredFrameData_HeadPoseEstimate, OF_RequiredFrameData_Avatar }
    return { OF_RequiredFrameData_FaceLandmarker, OF_RequiredFrameData_Avatar }
end

function setBoneRotation(name, x, y, z)
    local bone = avatar:getTransform():find(name)

    -- print("setBoneRotation---", bone)

    local localPosition = bone:getLocalPosition()
    local rot = Quaternion.EulerRadians(x, y, z)
    local localScale = bone:getLocalScale()

    bone:setLocalPosition(localPosition)
    bone:setLocalRotation(rot)
    bone:setLocalScale(localScale)
    --local mat = Matrix4f.TRS(localPosition, rot, localScale)
    --bone:updateTransform(mat)
end

function printRotation(node)
    local rot = node:getLocalRotation()
    OF_LOGI(TAG, string.format("rot : %.2f, %.2f, %.2f", rot.x, rot.y, rot.z))
end

function applyRGBA(context, filter, frameData, inTex, outTex, debugTex)
    local width = outTex.width
    local height = outTex.height
    
    -- debug landmark to out put texture.
    if Config.ShowLandmarks == true then
        context:bindFBO(outTex)
        context:setClearColor(0.3, 0.3, 0.5, 1.0)
        context:clearColorBuffer()
        context:setViewport(0, 0, width/4, height/4)
        
        quadRender = context:sharedQuadRender()
        copyPass = context:sharedCopyPass()
        copyPass:use()
        copyPass:setUniformTexture("uTexture0", 0, inTex.textureID, TEXTURE_2D)
        --quadRender:draw(copyPass, false)
        
        -- update and draw the landmarks
        if frameData.faceFrameDataArr.faceCount > 0 then
            local faceData = frameData.faceFrameDataArr.faceItemArr[1]
            updatePoints(context, faceData.facePoints)
            context:setBlend(true)
            context:setBlendMode(RS_BlendFunc_SRC_ALPHA, RS_BlendFunc_INV_SRC_ALPHA)
            point_program:use()
            --point_render:draw(point_program, false)
            context:setBlend(false)
        end
        context:setViewport(0, 0, width, height)
    else
        context:copyTexture(inTex, outTex)
    end
    
    context:bindFBOWithSharedDepthTexture(outTex)
    context:setViewport(0, 0, width, height)
    context:clearDepthBuffer()

    if _camera:getTargetWidth() ~= width or _camera:getTargetHeight() ~= height then
        _camera:setTargetSize(width, height)
    end

    --
    -- set blendshape weight if any face exists
    --
    local headRot = Vec3f.new()
    if frameData.faceFrameDataArr.faceCount > 0 then
        local faceData = frameData.faceFrameDataArr.faceItemArr[1]
        --print(faceData.blendshapeWeightMap[22])
        
        local mat = Matrix4f.new()
        mat:set(faceData.faceMesh.modelViewMat)
        local rot = mat:getRot()
        -- OF_LOGI(TAG, string.format("rot : %.2f, %.2f, %.2f", rot.x, rot.y, rot.z))
        
        headRot.x = -1.0 * rot.x
        if rot.y > 0.0 then 
            headRot.y = -math.pi + rot.y 
        else 
            headRot.y = math.pi + rot.y 
        end
        if rot.z > 0.0 then 
            headRot.z = math.pi - rot.z 
        else 
            headRot.z = -math.pi - rot.z 
        end
        
        local skinnedMeshRenderer = avatar:getTransform():find("head"):getEntity():getComponentSkinnedMeshRenderer()
        for i = 1, #Config.FaceAction do
            local weight = faceData.blendshapeWeightMap[i] --* 100.0
            for idx = 1, #Config.FaceAction[i].shapeIdx do
                local shapeIdx = Config.FaceAction[i].shapeIdx[idx]
                if shapeIdx >= 0 then
                    -- print(shapeIdx .. " : " .. weight)
                    skinnedMeshRenderer:setBlendShapeWeight(shapeIdx, weight)
                end
                -- if Config.FaceAction[i].name == "jawOpen" then
                --     local teethSkin = avatar:getTransform():find("down_teeth"):getEntity():getComponentSkinnedMeshRenderer()
                --     if teethSkin then
                --         teethSkin:setBlendShapeWeight(0, weight)
                --     end
                -- end
            end
        end

        --setBoneRotation("Bip001/joint_HipMaster/joint_Torso/joint_Torso2/transform1/joint_Neck/joint_Head", -rot.y * 180 / math.pi, rot.z * 180 / math.pi, -rot.x * 180 / math.pi - 10)
        
        setBoneRotation("Ybear_haed", rot.x, -rot.y, -rot.z)
        
        local w = faceData.blendshapeWeightMap[25]
        if w < 0.2 then w = w / 10
        else w = w * 1.5
        end
        if w > 1.0 then w = 1.0 end

		local jawOpen = w * (40 * math.pi / 180)
        local jawLeft = faceData.blendshapeWeightMap[24] * (-40 * math.pi / 180)
        local jawRight = faceData.blendshapeWeightMap[26] * (40 * math.pi / 180)
		setBoneRotation("Ybear_haed/jaw1", jawOpen, jawLeft + jawRight)

		--[[
        if skinnedMeshRenderer then
			print("---------------")
			local mesh = skinnedMeshRenderer:getMesh()
			local shapeCount = mesh:getBlendShapeCount()
			for i = 1, shapeCount do
				local index = i - 1
				local name = mesh:getBlendShapeName(index)
				print(i-1, name)
			end
        end
		]]
    end
    
    -- print(filter:floatParam("TranslateX"), filter:floatParam("TranslateY"), filter:floatParam("TranslateZ"))
    local trs = avatar:getTransform()
    trs:setPosition(Vec3f.new(
        filter:floatParam("TranslateX"),
        filter:floatParam("TranslateY"),
        filter:floatParam("TranslateZ")))
    trs:setRotation(Quaternion.EulerDegree(
        filter:floatParam("RotateX"),
        filter:floatParam("RotateY"),
        filter:floatParam("RotateZ")))
    trs:setScale(Vec3f.new(filter:floatParam("Scale"), filter:floatParam("Scale"), filter:floatParam("Scale")))
    
    _world:update()
    --printRotation(node)
    _world:render()
    --printRotation(node)

    context:unbindFBOWithDepthBuffer()

    -- debug
    if debugTex ~= nil then
        context:copyTexture(inTex, debugTex)
        if frameData.faceFrameDataArr.faceCount > 0 then
			if Config.ShowLandmarks == true then
				context:setBlend(true)
				context:setBlendMode(RS_BlendFunc_SRC_ALPHA, RS_BlendFunc_INV_SRC_ALPHA)
				point_program:use()
				point_render:draw(point_program, false)
				context:setBlend(false)
			end
			if Config.ShowFaceMesh then
				local faceData = frameData.faceFrameDataArr.faceItemArr[1]
				--FaceMesh:draw(faceData, frameData.timestamp, debugTex)
			end
        end
    end

    _renderStatesRestorer:restore()

    -------------------------------------------

    -- _renderStatesRestorer:save()

    -- local width = outTex.width
    -- local height = outTex.height

    -- context:copyTexture(inTex, outTex)
    -- context:bindFBOWithSharedDepthTexture(outTex)

    -- if _camera:getTargetWidth() ~= width or _camera:getTargetHeight() ~= height then
    --     _camera:setTargetSize(width, height)
    -- end

    -- _world:update()
    -- _world:render()

    -- context:unbindFBOWithDepthBuffer()

    -- if debugTex ~= nil then
    --     context:copyTexture(inTex, debugTex)
    -- end

    -- _renderStatesRestorer:restore()

    return OF_Result_Success
end

function readObject(context, filter, archiveIn)
end

function writeObject(context, filter, archiveOut)
end