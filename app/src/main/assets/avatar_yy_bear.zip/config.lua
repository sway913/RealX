return {
    FaceAction = 
    {
        { name = "browDownLeft",        shapeIdx = { 0} },  -- 0
        { name = "browDownRight",       shapeIdx = { 1} },  -- 1
        { name = "browInnerUp",         shapeIdx = { 2} },  -- 2
        { name = "browOuterUpLeft",     shapeIdx = { 3} },  -- 3
        { name = "browOuterUpRight",    shapeIdx = { 4} },  -- 4
        { name = "cheekPuff",           shapeIdx = { 5} },  -- 5
        { name = "cheekSquintLeft",     shapeIdx = { 6} },  -- 6
        { name = "cheekSquintRight",    shapeIdx = { 7} },  -- 7
        { name = "eyeBlinkLeft",        shapeIdx = { 8} },  -- 8
        { name = "eyeBlinkRight",       shapeIdx = { 9} },   -- 9
        { name = "eyeLookDownLeft",     shapeIdx = { 10} },   -- 10
        { name = "eyeLookDownRight",    shapeIdx = { 11} },   -- 11
        { name = "eyeLookInLeft",       shapeIdx = { 12} },   -- 12
        { name = "eyeLookInRight",      shapeIdx = { 13} },   -- 13
        { name = "eyeLookOutLeft",      shapeIdx = { 14} },   -- 14
        { name = "eyeLookOutRight",     shapeIdx = { 15} },   -- 15
        { name = "eyeLookUpLeft",       shapeIdx = { 16} },   -- 16
        { name = "eyeLookUpRight",      shapeIdx = { 17} },   -- 17
        { name = "eyeSquintLeft",       shapeIdx = { 20} },   -- 18
        { name = "eyeSquintRight",      shapeIdx = { 21} },   -- 19
        { name = "eyeWideLeft",         shapeIdx = { 22} },   -- 20
        { name = "eyeWideRight",        shapeIdx = { 23} },   -- 21
        { name = "jawForward",          shapeIdx = {  } },   -- 22
        { name = "jawLeft",             shapeIdx = {  } },  -- 23
        { name = "jawOpen",             shapeIdx = {  } },  -- 24
        { name = "jawRight",            shapeIdx = {  } },  -- 25
        { name = "mouthClose",          shapeIdx = {  } },   -- 26
        { name = "mouthDimpleLeft",     shapeIdx = { } },   -- 27
        { name = "mouthDimpleRight",    shapeIdx = { } },   -- 28
        { name = "mouthFrownLeft",      shapeIdx = { } },   -- 29
        { name = "mouthFrownRight",     shapeIdx = { } },   -- 30
        { name = "mouthFunnel",         shapeIdx = { 28} },  -- 31
        { name = "mouthLeft",           shapeIdx = { 29} },   -- 32
        { name = "mouthLowerDownLeft",  shapeIdx = { 30} },  -- 33
        { name = "mouthLowerDownRight", shapeIdx = { 31} },  -- 34
        { name = "mouthPressLeft",      shapeIdx = { } },   -- 35
        { name = "mouthPressRight",     shapeIdx = { } },   -- 36
        { name = "mouthPucker",         shapeIdx = { 34} },  -- 37
        { name = "mouthRight",          shapeIdx = { 35} },   -- 38
        { name = "mouthRollLower",      shapeIdx = { 36} },   -- 39
        { name = "mouthRollUpper",      shapeIdx = { 37} },   -- 40
        { name = "mouthShrugLower",     shapeIdx = { 38} },   -- 41
        { name = "mouthShrugUpper",     shapeIdx = { 39} },   -- 42
        { name = "mouthSmileLeft",      shapeIdx = { 40} },  -- 43
        { name = "mouthSmileRight",     shapeIdx = { 41} },  -- 44
        { name = "mouthStretchLeft",    shapeIdx = { 42} },  -- 45
        { name = "mouthStretchRight",   shapeIdx = { 43} },  -- 46
        { name = "mouthUpperUpLeft",    shapeIdx = { 44} },  -- 47
        { name = "mouthUpperUpRight",   shapeIdx = { 45} },  -- 48
        { name = "noseSneerLeft",       shapeIdx = { 46} },  -- 49
        { name = "noseSneerRight",      shapeIdx = { 47} },  -- 50
    },
    ShowLandmarks = true,
}
