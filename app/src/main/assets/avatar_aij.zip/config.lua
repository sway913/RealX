return {
    FaceAction = 
    {
        { name = "browDownLeft",        shapeIdx = { 1} },  -- 0
        { name = "browDownRight",       shapeIdx = { 0} },  -- 1
        { name = "browInnerUp",         shapeIdx = { 2} },  -- 2
        { name = "browOuterUpLeft",     shapeIdx = { 4} },  -- 3
        { name = "browOuterUpRight",    shapeIdx = { 3} },  -- 4
        { name = "cheekPuff",           shapeIdx = { } },  -- 5
        { name = "cheekSquintLeft",     shapeIdx = { } },  -- 6
        { name = "cheekSquintRight",    shapeIdx = { } },  -- 7
        { name = "eyeBlinkLeft",        shapeIdx = { 6} },  -- 8
        { name = "eyeBlinkRight",       shapeIdx = { 5} },   -- 9
        { name = "eyeLookDownLeft",     shapeIdx = { } },   -- 10
        { name = "eyeLookDownRight",    shapeIdx = { } },   -- 11
        { name = "eyeLookInLeft",       shapeIdx = { } },   -- 12
        { name = "eyeLookInRight",      shapeIdx = { } },   -- 13
        { name = "eyeLookOutLeft",      shapeIdx = { } },   -- 14
        { name = "eyeLookOutRight",     shapeIdx = { } },   -- 15
        { name = "eyeLookUpLeft",       shapeIdx = { } },   -- 16
        { name = "eyeLookUpRight",      shapeIdx = { } },   -- 17
        { name = "eyeSquintLeft",       shapeIdx = { } },   -- 18
        { name = "eyeSquintRight",      shapeIdx = { } },   -- 19
        { name = "eyeWideLeft",         shapeIdx = { } },   -- 20
        { name = "eyeWideRight",        shapeIdx = { } },   -- 21
        { name = "jawForward",          shapeIdx = {  } },   -- 22
        { name = "jawLeft",             shapeIdx = {  } },  -- 23
        { name = "jawOpen",             shapeIdx = { 7} },  -- 24
        { name = "jawRight",            shapeIdx = {  } },  -- 25
        { name = "mouthClose",          shapeIdx = {  } },   -- 26
        { name = "mouthDimpleLeft",     shapeIdx = { } },   -- 27
        { name = "mouthDimpleRight",    shapeIdx = { } },   -- 28
        { name = "mouthFrownLeft",      shapeIdx = { } },   -- 29
        { name = "mouthFrownRight",     shapeIdx = { } },   -- 30
        { name = "mouthFunnel",         shapeIdx = { 11} },  -- 31
        { name = "mouthLeft",           shapeIdx = { 12} },   -- 32
        { name = "mouthLowerDownLeft",  shapeIdx = { 12} },  -- 33
        { name = "mouthLowerDownRight", shapeIdx = { } },  -- 34
        { name = "mouthPressLeft",      shapeIdx = { } },   -- 35
        { name = "mouthPressRight",     shapeIdx = { } },   -- 36
        { name = "mouthPucker",         shapeIdx = { } },  -- 37
        { name = "mouthRight",          shapeIdx = { } },   -- 38
        { name = "mouthRollLower",      shapeIdx = { } },   -- 39
        { name = "mouthRollUpper",      shapeIdx = { } },   -- 40
        { name = "mouthShrugLower",     shapeIdx = { } },   -- 41
        { name = "mouthShrugUpper",     shapeIdx = { } },   -- 42
        { name = "mouthSmileLeft",      shapeIdx = { 15} },  -- 43
        { name = "mouthSmileRight",     shapeIdx = { 14} },  -- 44
        { name = "mouthStretchLeft",    shapeIdx = { } },  -- 45
        { name = "mouthStretchRight",   shapeIdx = { } },  -- 46
        { name = "mouthUpperUpLeft",    shapeIdx = { } },  -- 47
        { name = "mouthUpperUpRight",   shapeIdx = { } },  -- 48
        { name = "noseSneerLeft",       shapeIdx = { } },  -- 49
        { name = "noseSneerRight",      shapeIdx = { } },  -- 50
    },
    ShowLandmarks = true,
}
